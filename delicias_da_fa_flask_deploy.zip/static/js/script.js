// Funções JavaScript para o site Delícias da Fa

// Toggle do menu mobile
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navMenu = document.querySelector('.nav-menu');
    
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }
    
    // Fechar menu ao clicar em um link
    const navLinks = document.querySelectorAll('.nav-menu a');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            navMenu.classList.remove('active');
        });
    });
    
    // Validação de formulários
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Obrigado pelo seu contato! Esta é uma demonstração, por favor utilize WhatsApp ou Instagram para contato real.');
            this.reset();
        });
    }
    
    // Efeitos de scroll
    window.addEventListener('scroll', function() {
        const header = document.querySelector('header');
        if (window.scrollY > 50) {
            header.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
        } else {
            header.style.boxShadow = 'none';
        }
    });
    
    // Animação para cards de produtos
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
    
    // Geração automática de slug a partir do nome da categoria
    const categoryNameInput = document.getElementById('name');
    const categorySlugInput = document.getElementById('slug');
    
    if (categoryNameInput && categorySlugInput) {
        categoryNameInput.addEventListener('input', function() {
            // Só gera o slug automaticamente se o campo estiver vazio ou não tiver sido editado manualmente
            if (!categorySlugInput.dataset.edited) {
                const slug = this.value
                    .toLowerCase()
                    .replace(/[^\w\s-]/g, '') // Remove caracteres especiais
                    .replace(/\s+/g, '-')     // Substitui espaços por hífens
                    .replace(/--+/g, '-');    // Remove hífens duplicados
                
                categorySlugInput.value = slug;
            }
        });
        
        // Marca o campo de slug como editado manualmente
        categorySlugInput.addEventListener('input', function() {
            this.dataset.edited = true;
        });
    }
});
