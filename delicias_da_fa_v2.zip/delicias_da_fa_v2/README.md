# Delícias da Fa - Site de Bolos com Painel Administrativo

## Sobre o Projeto
Este é um site profissional para a venda de bolos da marca "Delícias da Fa", desenvolvido em Flask (Python) com banco de dados SQLite e painel administrativo completo para gerenciamento de produtos.

## Estrutura do Projeto
- `venv/`: Ambiente virtual Python
- `src/`: Código-fonte do projeto
  - `models/`: Modelos de dados
  - `routes/`: Rotas da aplicação
  - `static/`: Arquivos estáticos (CSS, JS, imagens)
  - `templates/`: Templates HTML
  - `main.py`: Arquivo principal da aplicação

## Funcionalidades
- **Páginas Públicas**:
  - Home page
  - Menu geral
  - Páginas específicas para cada categoria de bolo
  - Página de contato

- **Painel Administrativo**:
  - Login seguro
  - Dashboard administrativo
  - Gerenciamento completo de produtos (CRUD)
  - Gerenciamento de categorias (CRUD)
  - Upload de imagens

## Instruções de Uso

### Requisitos
- Python 3.6+
- Pip (gerenciador de pacotes Python)

### Instalação
1. Extraia o arquivo zip em uma pasta de sua preferência
2. Abra o terminal/prompt de comando na pasta do projeto
3. Crie um ambiente virtual:
   ```
   python -m venv venv
   ```
4. Ative o ambiente virtual:
   - Windows: `venv\Scripts\activate`
   - Linux/Mac: `source venv/bin/activate`
5. Instale as dependências:
   ```
   pip install -r requirements.txt
   ```

### Execução
1. Com o ambiente virtual ativado, execute:
   ```
   python src/main.py
   ```
2. Acesse o site em seu navegador: `http://localhost:5000`

### Acesso ao Painel Administrativo
- URL: `http://localhost:5000/auth/login`
- Usuário: `admin`
- Senha: `admin123`

## Gerenciamento de Conteúdo
No painel administrativo, você pode:
- Adicionar, editar e excluir produtos
- Adicionar, editar e excluir categorias
- Fazer upload de imagens para usar nos produtos

## Personalização
- Para alterar o logo, substitua o arquivo `src/static/img/logo.jpg`
- Para modificar as cores, edite o arquivo `src/static/css/style.css`

## Contato
Para suporte ou dúvidas, entre em contato através do WhatsApp ou Instagram indicados no site.
